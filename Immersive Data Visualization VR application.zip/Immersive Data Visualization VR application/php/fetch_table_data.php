<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

$dbServer = "localhost";
$dbUsername = "qrapacsf_XR_ogbonda_glory";
$dbPassword = "ivLmSSgaN5QVZ9A";
$dbName = "qrapacsf_immersive_data_vis";

$conn = new mysqli($dbServer, $dbUsername, $dbPassword, $dbName);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$tableName = isset($_GET['table_name']) ? $_GET['table_name'] : '';

$sql = "SELECT * FROM `$tableName`";
$result = $conn->query($sql);

$rows = array();

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
  }
}

$conn->close();

echo json_encode($rows);
?>
